const config = {
	API_URL: process.env.VITE_API_URL,
}

export default config
