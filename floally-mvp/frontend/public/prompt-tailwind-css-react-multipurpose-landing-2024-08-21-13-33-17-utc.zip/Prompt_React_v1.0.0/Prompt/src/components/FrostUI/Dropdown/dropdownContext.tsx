import { createContext } from 'react'

export const DropdownContext = createContext<any>(false)
