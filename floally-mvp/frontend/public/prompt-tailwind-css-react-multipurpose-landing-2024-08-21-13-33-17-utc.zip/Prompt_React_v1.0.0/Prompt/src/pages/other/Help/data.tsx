// types
import { HelpLink } from './types'

const helpLinks: HelpLink[] = [
	{
		icon: (
			<svg
				className="w-12 h-12 text-primary"
				viewBox="0 0 24 24"
				version="1.1"
				xmlns="http://www.w3.org/2000/svg"
				xmlnsXlink="http://www.w3.org/1999/xlink"
			>
				{' '}
				<g stroke="none" strokeWidth={1} fill="none" fillRule="evenodd">
					{' '}
					<polygon id="Shape" points="0 0 24 0 24 24 0 24" />{' '}
					<path
						d="M3.70710678,15.7071068 C3.31658249,16.0976311 2.68341751,16.0976311 2.29289322,15.7071068 C1.90236893,15.3165825 1.90236893,14.6834175 2.29289322,14.2928932 L8.29289322,8.29289322 C8.67147216,7.91431428 9.28105859,7.90106866 9.67572463,8.26284586 L15.6757246,13.7628459 C16.0828436,14.1360383 16.1103465,14.7686056 15.7371541,15.1757246 C15.3639617,15.5828436 14.7313944,15.6103465 14.3242754,15.2371541 L9.03007575,10.3841378 L3.70710678,15.7071068 Z"
						id="Path-94"
						fill="currentcolor"
						transform="translate(9.000003, 11.999999) rotate(-270.000000) translate(-9.000003, -11.999999) "
					/>{' '}
					<rect
						id="Rectangle"
						fill="currentcolor"
						opacity="0.3"
						x={12}
						y={17}
						width={10}
						height={2}
						rx={1}
					/>{' '}
				</g>{' '}
			</svg>
		),
		title: 'Getting started',
		links: ['General information', 'Signup help', 'Preparing the documents'],
	},
	{
		icon: (
			<svg
				className="w-12 h-12 text-primary"
				viewBox="0 0 24 24"
				version="1.1"
				xmlns="http://www.w3.org/2000/svg"
				xmlnsXlink="http://www.w3.org/1999/xlink"
			>
				{' '}
				<g stroke="none" strokeWidth={1} fill="none" fillRule="evenodd">
					{' '}
					<rect id="bound" x={0} y={0} width={24} height={24} />{' '}
					<path
						d="M6,2 L18,2 C19.6568542,2 21,3.34314575 21,5 L21,19 C21,20.6568542 19.6568542,22 18,22 L6,22 C4.34314575,22 3,20.6568542 3,19 L3,5 C3,3.34314575 4.34314575,2 6,2 Z M12,11 C13.1045695,11 14,10.1045695 14,9 C14,7.8954305 13.1045695,7 12,7 C10.8954305,7 10,7.8954305 10,9 C10,10.1045695 10.8954305,11 12,11 Z M7.00036205,16.4995035 C6.98863236,16.6619875 7.26484009,17 7.4041679,17 C11.463736,17 14.5228466,17 16.5815,17 C16.9988413,17 17.0053266,16.6221713 16.9988413,16.5 C16.8360465,13.4332455 14.6506758,12 11.9907452,12 C9.36772908,12 7.21569918,13.5165724 7.00036205,16.4995035 Z"
						id="Combined-Shape"
						fill="currentcolor"
					/>{' '}
				</g>{' '}
			</svg>
		),
		title: 'Managing my account',
		links: [
			'Account information',
			'Identity verification',
			'Linking a paymeny method',
		],
	},
	{
		icon: (
			<svg
				className="w-12 h-12 text-primary"
				viewBox="0 0 24 24"
				version="1.1"
				xmlns="http://www.w3.org/2000/svg"
				xmlnsXlink="http://www.w3.org/1999/xlink"
			>
				{' '}
				<g stroke="none" strokeWidth={1} fill="none" fillRule="evenodd">
					{' '}
					<rect id="Rectangle-5" x={0} y={0} width={24} height={24} />{' '}
					<path
						d="M6,7 C7.1045695,7 8,6.1045695 8,5 C8,3.8954305 7.1045695,3 6,3 C4.8954305,3 4,3.8954305 4,5 C4,6.1045695 4.8954305,7 6,7 Z M6,9 C3.790861,9 2,7.209139 2,5 C2,2.790861 3.790861,1 6,1 C8.209139,1 10,2.790861 10,5 C10,7.209139 8.209139,9 6,9 Z"
						id="Oval-7"
						fill="currentcolor"
					/>{' '}
					<path
						d="M7,11.4648712 L7,17 C7,18.1045695 7.8954305,19 9,19 L15,19 L15,21 L9,21 C6.790861,21 5,19.209139 5,17 L5,8 L5,7 L7,7 L7,8 C7,9.1045695 7.8954305,10 9,10 L15,10 L15,12 L9,12 C8.27142571,12 7.58834673,11.8052114 7,11.4648712 Z"
						id="Combined-Shape"
						fill="currentcolor"
						opacity="0.3"
					/>{' '}
					<path
						d="M18,22 C19.1045695,22 20,21.1045695 20,20 C20,18.8954305 19.1045695,18 18,18 C16.8954305,18 16,18.8954305 16,20 C16,21.1045695 16.8954305,22 18,22 Z M18,24 C15.790861,24 14,22.209139 14,20 C14,17.790861 15.790861,16 18,16 C20.209139,16 22,17.790861 22,20 C22,22.209139 20.209139,24 18,24 Z"
						id="Oval-7-Copy"
						fill="currentcolor"
					/>{' '}
					<path
						d="M18,13 C19.1045695,13 20,12.1045695 20,11 C20,9.8954305 19.1045695,9 18,9 C16.8954305,9 16,9.8954305 16,11 C16,12.1045695 16.8954305,13 18,13 Z M18,15 C15.790861,15 14,13.209139 14,11 C14,8.790861 15.790861,7 18,7 C20.209139,7 22,8.790861 22,11 C22,13.209139 20.209139,15 18,15 Z"
						id="Oval-7-Copy-3"
						fill="currentcolor"
					/>{' '}
				</g>{' '}
			</svg>
		),
		title: 'API & Integrations',
		links: ['Rest API Integrations', 'API SDKs', 'Embed scripts'],
	},
]

export { helpLinks }
