export type TeamMember = {
	avatar: string
	name: string
	designation: string
}
